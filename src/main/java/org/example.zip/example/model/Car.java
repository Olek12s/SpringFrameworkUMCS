package org.example.model;

public class Car extends Vehicle
{

    public Car(String brand, String model, int year, int price)
    {
        super(brand, model, year, price);
    }
}
